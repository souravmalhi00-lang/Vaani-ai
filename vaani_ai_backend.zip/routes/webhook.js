const express = require('express');
const router = express.Router();
const axios = require('axios');
const db = require('../models/database');
const { getOpenAIReply } = require('../utils/openai');

router.post('/', async (req, res) => {
    const chat_id = req.body.message.chat.id;
    const text = req.body.message.text;

    try {
        const aiReply = await getOpenAIReply(text);

        await axios.post(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
            chat_id: chat_id,
            text: aiReply,
        });

        res.sendStatus(200);
    } catch (error) {
        console.error('Webhook Error:', error.message);
        res.sendStatus(500);
    }
});

module.exports = router;