const express = require('express');
const app = express();
require('dotenv').config();
const webhookRoute = require('./routes/webhook');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const db = require('./models/database');

app.use(express.json());
app.use('/webhook', webhookRoute);

app.get('/', (req, res) => {
    res.send('🚀 Vaani AI Backend is Running');
});

app.listen(process.env.PORT || 3000, () => {
    console.log('Server started on port', process.env.PORT || 3000);
});